from .Otter import Algebra as algebra
from .Otter import Interpolation as interpolation